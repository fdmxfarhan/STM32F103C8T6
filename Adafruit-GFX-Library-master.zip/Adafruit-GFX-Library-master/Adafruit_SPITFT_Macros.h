// THIS FILE INTENTIONALLY LEFT BLANK.

// Macros previously #defined here have been made into (mostly) inline
// functions in the Adafruit_SPITFT class. Other libraries might still
// contain code trying to #include this header file, so until everything's
// updated this file still exists (but doing nothing) to avoid trouble.
